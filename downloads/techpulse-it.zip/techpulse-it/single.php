<?php get_header(); ?>

<main class="section single-post">
    <?php if (have_posts()) : ?>
        <?php while (have_posts()) : the_post(); ?>

            <article <?php post_class('post-content'); ?>>

                <div class="section-header">
                    <h1><?php the_title(); ?></h1>

                    <p class="post-meta">
                        Posted on <?php echo get_the_date(); ?> by <?php the_author(); ?>
                    </p>
                </div>

                <?php if (has_post_thumbnail()) : ?>
                    <div class="post-featured-image">
                        <?php the_post_thumbnail('large'); ?>
                    </div>
                <?php endif; ?>

                <div class="page-content">
                    <?php the_content(); ?>
                </div>

                <div class="post-tags">
                    <?php the_tags('<span>Tags: </span>', ', ', ''); ?>
                </div>

                <div class="post-navigation">
                    <div><?php previous_post_link('%link', '← Previous Post'); ?></div>
                    <div><?php next_post_link('%link', 'Next Post →'); ?></div>
                </div>

            </article>

        <?php endwhile; ?>
    <?php endif; ?>
</main>

<?php get_footer(); ?>