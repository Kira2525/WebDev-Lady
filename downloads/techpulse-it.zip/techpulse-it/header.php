<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header">

    <?php if (has_custom_logo()) : ?>
        <?php the_custom_logo(); ?>
    <?php else : ?>
        <a class="logo" href="<?php echo esc_url(home_url('/')); ?>">
            Tech<span>Pulse</span> IT
        </a>
    <?php endif; ?>

    <nav class="nav" aria-label="Main Navigation">
        <?php
        wp_nav_menu(array(
            'theme_location' => 'primary',
            'container'      => false,
            'fallback_cb'    => 'techpulse_it_fallback_menu',
        ));
        ?>
    </nav>

</header>