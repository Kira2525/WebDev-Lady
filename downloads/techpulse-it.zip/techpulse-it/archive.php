<?php
/**
 * Archive Template
 */

get_header();
?>

<main class="section">

    <div class="container">

        <div class="section-heading">

            <span class="eyebrow">Archive</span>

            <h1>
                <?php the_archive_title(); ?>
            </h1>

            <p>
                Browse posts, updates, and resources from TechPulse IT.
            </p>

        </div>

        <?php if (have_posts()) : ?>

            <div class="services-grid">

                <?php while (have_posts()) : the_post(); ?>

                    <article <?php post_class('service-card blog-card'); ?>>

                        <?php if (has_post_thumbnail()) : ?>
                            <a href="<?php the_permalink(); ?>" class="blog-thumbnail">
                                <?php the_post_thumbnail('large'); ?>
                            </a>
                        <?php endif; ?>

                        <div class="blog-meta">
                            <span><?php echo esc_html(get_the_date()); ?></span>
                        </div>

                        <h3>
                            <a href="<?php the_permalink(); ?>">
                                <?php the_title(); ?>
                            </a>
                        </h3>

                        <p>
                            <?php echo esc_html(wp_trim_words(get_the_excerpt(), 24)); ?>
                        </p>

                        <a class="btn-primary" href="<?php the_permalink(); ?>">
                            Read More
                        </a>

                    </article>

                <?php endwhile; ?>

            </div>

            <div class="pagination-wrapper">
                <?php
                the_posts_pagination(array(
                    'mid_size'  => 2,
                    'prev_text' => '← Previous',
                    'next_text' => 'Next →',
                ));
                ?>
            </div>

        <?php else : ?>

            <div class="info-box">
                <h2>No Posts Found</h2>
                <p>There are no posts in this archive yet.</p>
            </div>

        <?php endif; ?>

    </div>

</main>

<?php get_footer(); ?>