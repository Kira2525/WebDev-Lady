<?php
/**
 * Template Name: Pricing Page
 */

get_header();
?>

<main>

    <!-- HERO -->
    <section class="page-hero">
        <div class="container">
            <span class="eyebrow">Pricing Plans</span>

            <h1>Simple IT Support Plans For Every Business</h1>

            <p>
                Choose a support plan that fits your business needs, budget,
                and technology goals.
            </p>
        </div>
    </section>

    <!-- PRICING -->
    <section class="section">
        <div class="container">

            <div class="section-heading">
                <span class="eyebrow">Monthly Support</span>
                <h2>Flexible Plans Built For Growing Teams</h2>
                <p>
                    These pricing cards can be edited for monthly IT plans,
                    repair packages, cybersecurity services, or custom support.
                </p>
            </div>

            <div class="pricing-grid">

                <div class="pricing-card">
                    <h3>Starter</h3>
                    <p class="plan-text">For small teams that need basic IT help.</p>

                    <div class="price">
                        <strong>$99</strong>
                        <span>/mo</span>
                    </div>

                    <ul>
                        <li>Basic remote support</li>
                        <li>Email support</li>
                        <li>Device setup help</li>
                        <li>Monthly system check</li>
                    </ul>

                    <a href="<?php echo esc_url( home_url('/contact/') ); ?>" class="btn-primary">
                        Choose Plan
                    </a>
                </div>

                <div class="pricing-card featured-card">
                    <span class="popular-badge">Most Popular</span>

                    <h3>Business</h3>
                    <p class="plan-text">For businesses that need stronger support.</p>

                    <div class="price">
                        <strong>$249</strong>
                        <span>/mo</span>
                    </div>

                    <ul>
                        <li>Priority support</li>
                        <li>Security monitoring</li>
                        <li>Cloud backup guidance</li>
                        <li>Network troubleshooting</li>
                        <li>Monthly reporting</li>
                    </ul>

                    <a href="<?php echo esc_url( home_url('/contact/') ); ?>" class="btn-primary">
                        Choose Plan
                    </a>
                </div>

                <div class="pricing-card">
                    <h3>Pro</h3>
                    <p class="plan-text">For growing teams that need full IT support.</p>

                    <div class="price">
                        <strong>$499</strong>
                        <span>/mo</span>
                    </div>

                    <ul>
                        <li>Managed IT support</li>
                        <li>Cybersecurity checks</li>
                        <li>Remote and onsite help</li>
                        <li>Business technology planning</li>
                        <li>Advanced support requests</li>
                    </ul>

                    <a href="<?php echo esc_url( home_url('/contact/') ); ?>" class="btn-primary">
                        Choose Plan
                    </a>
                </div>

            </div>

        </div>
    </section>

    <!-- SERVICE PACKAGES -->
    <section class="section alt-section">
        <div class="container">

            <div class="section-heading">
                <span class="eyebrow">One-Time Services</span>
                <h2>Project-Based IT Pricing</h2>
                <p>
                    Use this area for computer repairs, setup fees, security audits,
                    or custom technology projects.
                </p>
            </div>

            <div class="services-grid">

                <div class="service-card">
                    <h3>Computer Tune-Up</h3>
                    <p>
                        System cleanup, software checks, startup optimization,
                        and basic troubleshooting.
                    </p>
                    <strong>Starting at $79</strong>
                </div>

                <div class="service-card">
                    <h3>Network Setup</h3>
                    <p>
                        Wi-Fi setup, router configuration, printer setup,
                        and small office network support.
                    </p>
                    <strong>Starting at $149</strong>
                </div>

                <div class="service-card">
                    <h3>Security Review</h3>
                    <p>
                        Password review, antivirus checks, backup review,
                        and basic cybersecurity recommendations.
                    </p>
                    <strong>Starting at $199</strong>
                </div>

            </div>

        </div>
    </section>

    <!-- FAQ PREVIEW -->
    <section class="section">
        <div class="container">

            <div class="section-heading">
                <span class="eyebrow">Pricing Questions</span>
                <h2>Common Plan Questions</h2>
            </div>

            <div class="faq-list">

                <div class="faq-item">
                    <h3>Can the prices be changed?</h3>
                    <p>
                        Yes. Buyers can edit the prices directly in the WordPress
                        page template or page content.
                    </p>
                </div>

                <div class="faq-item">
                    <h3>Can this be used for repair shops?</h3>
                    <p>
                        Yes. The pricing sections work for IT support, computer repair,
                        managed services, and cybersecurity businesses.
                    </p>
                </div>

                <div class="faq-item">
                    <h3>Can I offer custom quotes?</h3>
                    <p>
                        Yes. Use the contact button to send visitors to a quote
                        request form.
                    </p>
                </div>

            </div>

        </div>
    </section>

    <!-- WHY CHOOSE US -->
    <section class="section">
        <div class="container">

            <div class="section-heading">
                <span class="eyebrow">Why Choose Us</span>
                <h2>Trusted Technology Support</h2>

                <p>
                    Businesses rely on TechPulse IT for dependable support,
                    proactive maintenance, and practical technology solutions.
                </p>
            </div>

            <div class="stats-grid">

                <div class="stat-card">
                    <strong>Fast</strong>
                    <span>Response Times</span>
                </div>

                <div class="stat-card">
                    <strong>Secure</strong>
                    <span>Technology Solutions</span>
                </div>

                <div class="stat-card">
                    <strong>Reliable</strong>
                    <span>Ongoing Support</span>
                </div>

                <div class="stat-card">
                    <strong>Scalable</strong>
                    <span>Business Growth</span>
                </div>

            </div>

        </div>
    </section>

    <!-- CTA -->
    <section class="section">
        <div class="container">
            <div class="cta-box">
                <h2>Need A Custom IT Plan?</h2>
                <p>
                    Contact TechPulse IT to request a custom quote based on
                    your business needs.
                </p>

                <a href="<?php echo esc_url( home_url('/contact/') ); ?>" class="btn-primary">
                    Request A Quote
                </a>
            </div>
        </div>
    </section>

</main>

<?php get_footer(); ?>
