<?php
/**
 * Template Name: About Page
 */

get_header();
?>

<main>

    <!-- ABOUT HERO -->
    <section class="page-hero">
        <div class="container">
            <span class="eyebrow">About TechPulse IT</span>

            <h1>Reliable IT Support for Modern Businesses</h1>

            <p>
                TechPulse IT is built for small businesses that need secure,
                dependable, and easy-to-understand technology support.
            </p>
        </div>
    </section>

    <!-- WHO WE ARE -->
    <section class="section">
        <div class="container split-layout">

            <div>
                <span class="eyebrow">Who We Are</span>

                <h2>
                    Helping Businesses Stay Connected,
                    Protected, and Productive
                </h2>

                <p>
                    TechPulse IT helps businesses manage the technology they rely
                    on every day. From computer support and network setup to
                    cybersecurity and cloud solutions, our mission is to keep
                    businesses running smoothly.
                </p>

                <p>
                    Whether customers need ongoing support, emergency
                    troubleshooting, or stronger security, TechPulse IT provides
                    dependable solutions designed for modern businesses.
                </p>
            </div>

            <div class="info-box">
                <h3>What We Specialize In</h3>

                <ul>
                    <li>Managed IT Services</li>
                    <li>Cybersecurity Solutions</li>
                    <li>Computer Repair</li>
                    <li>Cloud Services</li>
                    <li>Network Setup & Maintenance</li>
                    <li>Remote Help Desk Support</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- MISSION -->
    <section class="section alt-section">
        <div class="container split-layout">

            <div class="info-box">
                <h3>Our Mission</h3>

                <p>
                    To make business technology easier, safer, and more reliable
                    through responsive support and modern IT solutions.
                </p>
            </div>

            <div>
                <span class="eyebrow">Our Approach</span>

                <h2>
                    Simple Support.
                    Strong Security.
                    Real Results.
                </h2>

                <p>
                    We believe technology should help businesses grow, not create
                    obstacles. Our goal is to provide clear solutions, fast
                    response times, and proactive support.
                </p>

                <p>
                    By combining technical expertise with customer-focused
                    service, we help businesses stay productive and protected.
                </p>
            </div>

        </div>
    </section>

    <!-- WHY CHOOSE US -->
    <section class="section">
        <div class="container">

            <div class="section-heading">
                <span class="eyebrow">Why Choose Us</span>

                <h2>
                    Trusted Technology Support
                    For Growing Businesses
                </h2>

                <p>
                    Our services are designed to reduce downtime, improve
                    security, and give businesses confidence in their technology.
                </p>
            </div>

            <div class="services-grid">

                <div class="service-card">
                    <h3>Fast Response Times</h3>
                    <p>
                        Get help quickly when issues arise so your team can stay
                        productive.
                    </p>
                </div>

                <div class="service-card">
                    <h3>Security Focused</h3>
                    <p>
                        Protect your business with modern security practices,
                        monitoring, and backups.
                    </p>
                </div>

                <div class="service-card">
                    <h3>Business Driven</h3>
                    <p>
                        Technology solutions designed to support real business
                        goals and growth.
                    </p>
                </div>

            </div>

        </div>
    </section>

    <!-- STATS -->
    <section class="section alt-section">
        <div class="container stats-grid">

            <div class="stat-card">
                <strong>24/7</strong>
                <span>Monitoring Available</span>
            </div>

            <div class="stat-card">
                <strong>99%</strong>
                <span>Uptime Focus</span>
            </div>

            <div class="stat-card">
                <strong>100+</strong>
                <span>Business Solutions</span>
            </div>

            <div class="stat-card">
                <strong>5+</strong>
                <span>Core Service Areas</span>
            </div>

        </div>
    </section>

    <!-- CALL TO ACTION -->
    <section class="section">
        <div class="container">

            <div class="cta-box">

                <h2>Need Reliable IT Support?</h2>

                <p>
                    Contact TechPulse IT today to discuss your business
                    technology needs.
                </p>

                <a href="<?php echo esc_url( home_url('/contact/') ); ?>" class="btn-primary">
                    Request A Quote
                </a>

            </div>

        </div>
    </section>

</main>

<?php get_footer(); ?>
