<?php
/**
 * Template Name: Contact Page
 */

get_header();
?>

<main>

    <!-- HERO -->
    <section class="page-hero">
        <div class="container">

            <span class="eyebrow">Contact TechPulse IT</span>

            <h1>Let's Talk About Your Technology Needs</h1>

            <p>
                Have questions about IT support, cybersecurity, cloud services,
                or managed technology solutions? Get in touch with our team.
            </p>

        </div>
    </section>

    <!-- CONTACT SECTION -->
    <section class="section">

        <div class="container contact-layout">

            <!-- CONTACT INFO -->
            <div class="info-box">

                <h2>Get In Touch</h2>

                <p>
                    We're here to help businesses stay secure, productive,
                    and connected.
                </p>

                <div class="contact-item">
                    <h3>Phone</h3>
                    <p>(555) 123-4567</p>
                </div>

                <div class="contact-item">
                    <h3>Email</h3>
                    <p>support@techpulseit.com</p>
                </div>

                <div class="contact-item">
                    <h3>Location</h3>
                    <p>Phoenix, Arizona</p>
                </div>

                <div class="contact-item">
                    <h3>Business Hours</h3>
                    <p>
                        Monday - Friday<br>
                        8:00 AM - 5:00 PM
                    </p>
                </div>

            </div>

            <!-- CONTACT FORM -->
            <div class="info-box">

                <h2>Request Support</h2>

                <form class="contact-form">

                    <input
                        type="text"
                        placeholder="Full Name"
                        required
                    >

                    <input
                        type="email"
                        placeholder="Email Address"
                        required
                    >

                    <input
                        type="tel"
                        placeholder="Phone Number"
                    >

                    <input
                        type="text"
                        placeholder="Company Name"
                    >

                    <select required>
                        <option value="">Select Service</option>
                        <option>Managed IT Support</option>
                        <option>Cybersecurity</option>
                        <option>Computer Repair</option>
                        <option>Cloud Solutions</option>
                        <option>Network Setup</option>
                        <option>Help Desk Support</option>
                    </select>

                    <textarea
                        rows="6"
                        placeholder="Tell us about your project or issue..."
                        required
                    ></textarea>

                    <button
                        type="submit"
                        class="btn-primary"
                    >
                        Submit Request
                    </button>

                </form>

            </div>

        </div>

    </section>

    <!-- SUPPORT OPTIONS -->
    <section class="section alt-section">

        <div class="container">

            <div class="section-heading">

                <span class="eyebrow">
                    Why Choose TechPulse IT
                </span>

                <h2>
                    Business Technology Support You Can Trust
                </h2>

            </div>

            <div class="services-grid">

                <div class="service-card">
                    <h3>Fast Response Times</h3>
                    <p>
                        Quick assistance when your business needs help.
                    </p>
                </div>

                <div class="service-card">
                    <h3>Security Focused</h3>
                    <p>
                        Modern solutions that help keep your data safe.
                    </p>
                </div>

                <div class="service-card">
                    <h3>Experienced Support</h3>
                    <p>
                        Professional technology guidance and troubleshooting.
                    </p>
                </div>

            </div>

        </div>

    </section>

    <!-- CONTACT METHODS -->
    <section class="section">

        <div class="container">

            <div class="stats-grid">

                <div class="stat-card">
                    <strong>Phone</strong>
                    <span>(555) 123-4567</span>
                </div>

                <div class="stat-card">
                    <strong>Email</strong>
                    <span>support@techpulseit.com</span>
                </div>

                <div class="stat-card">
                    <strong>Hours</strong>
                    <span>Mon - Fri</span>
                </div>

                <div class="stat-card">
                    <strong>Location</strong>
                    <span>Phoenix, AZ</span>
                </div>

            </div>

        </div>

    </section>

    <!-- CTA -->
    <section class="section">

        <div class="container">

            <div class="cta-box">

                <h2>
                    Ready To Improve Your IT?
                </h2>

                <p>
                    Contact our team today and discover how TechPulse IT
                    can help your business grow.
                </p>

                <a
                    href="tel:5551234567"
                    class="btn-primary"
                >
                    Call Now
                </a>

            </div>

        </div>

    </section>

</main>

<?php get_footer(); ?>