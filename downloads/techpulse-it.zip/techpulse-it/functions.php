<?php

/**
 * Theme Setup
 */
function techpulse_it_setup() {

    add_theme_support('title-tag');

    add_theme_support('post-thumbnails');

    add_theme_support('custom-logo', array(
        'height'      => 80,
        'width'       => 240,
        'flex-height' => true,
        'flex-width'  => true,
    ));

    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));

    add_theme_support('custom-background');

    add_theme_support('custom-header');

    register_nav_menus(array(
        'primary' => __('Primary Menu', 'techpulse-it'),
    ));
}

add_action('after_setup_theme', 'techpulse_it_setup');


/**
 * Styles
 */
function techpulse_it_scripts() {

    wp_enqueue_style(
        'techpulse-it-style',
        get_stylesheet_uri(),
        array(),
        wp_get_theme()->get('Version')
    );
}

add_action('wp_enqueue_scripts', 'techpulse_it_scripts');


/**
 * Fallback Menu
 */
function techpulse_it_fallback_menu() {

    echo '<ul>';

    echo '<li><a href="' . esc_url(home_url('/')) . '">Home</a></li>';

    echo '<li><a href="' . esc_url(home_url('/about/')) . '">About</a></li>';

    echo '<li><a href="' . esc_url(home_url('/services/')) . '">Services</a></li>';

    echo '<li><a href="' . esc_url(home_url('/pricing/')) . '">Pricing</a></li>';

    echo '<li><a href="' . esc_url(home_url('/faq/')) . '">FAQ</a></li>';

    echo '<li><a href="' . esc_url(home_url('/contact/')) . '">Contact</a></li>';

    echo '</ul>';
}