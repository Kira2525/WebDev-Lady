TechPulse IT WordPress Theme
Version: 1.0
Author: Web Dev Lady

========================================
OVERVIEW
========

TechPulse IT is a modern WordPress theme designed for IT support companies, managed service providers (MSPs), cybersecurity firms, computer repair businesses, technology consultants, and other professional service companies.

The theme includes a professional homepage, service pages, pricing tables, FAQ section, contact page, blog support, responsive layouts, and custom logo support.

========================================
FEATURES
========

* Responsive Design
* Mobile Friendly
* Custom Logo Support
* WordPress Menu Support
* Blog Support
* Featured Images
* Homepage Hero Section
* Services Page
* Pricing Page
* FAQ Page
* Contact Page
* About Page
* Search Results Page
* Archive Page
* 404 Error Page
* Fast Loading
* Easy Customization

========================================
INCLUDED TEMPLATES
==================

front-page.php
index.php
page.php
single.php
archive.php
search.php
404.php

page-about.php
page-services.php
page-pricing.php
page-faq.php
page-contact.php

header.php
footer.php
functions.php
style.css

========================================
INSTALLATION
============

1. Upload the TechPulse IT theme folder to:

   wp-content/themes/

2. Log in to WordPress Admin.

3. Navigate to:

   Appearance > Themes

4. Activate TechPulse IT.

5. Create the following pages:

   * Home
   * About
   * Services
   * Pricing
   * FAQ
   * Contact

6. Assign the appropriate page templates:

   About → About Page
   Services → Services Page
   Pricing → Pricing Page
   FAQ → FAQ Page
   Contact → Contact Page

7. Set the Home page as the front page:

   Settings > Reading

   Homepage Displays:
   Static Page

   Homepage:
   Home

========================================
CUSTOMIZATION
=============

Theme colors can be edited in:

style.css

Main color variables are located near the top of the file:

--blue
--purple
--green
--bg
--bg-soft

Hero image location:

assets/it-hero.jpg

Replace this image with your own image while keeping the same filename.

========================================
RECOMMENDED IMAGE SIZE
======================

Hero Image:
1920 x 1080

Theme Screenshot:
1200 x 900

========================================
SUPPORT
=======

Thank you for purchasing TechPulse IT.

For customization services, support, or questions, please contact the author.

========================================
CHANGELOG
=========

Version 1.0

* Initial release
* Responsive design
* Homepage hero section
* Services page
* Pricing page
* FAQ page
* Contact page
* Blog support
* Search template
* Archive template
* 404 page
