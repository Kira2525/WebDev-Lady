<?php
/**
 * Template Name: Services Page
 */

get_header();
?>

<main>

    <!-- HERO -->
    <section class="page-hero">
        <div class="container">
            <span class="eyebrow">Our Services</span>

            <h1>Professional IT Services For Modern Businesses</h1>

            <p>
                From managed IT support to cybersecurity and cloud solutions,
                TechPulse IT helps businesses stay secure, connected, and productive.
            </p>
        </div>
    </section>

    <!-- SERVICES -->
    <section class="section">
        <div class="container">

            <div class="section-heading">
                <span class="eyebrow">What We Offer</span>

                <h2>Technology Solutions Built For Growth</h2>

                <p>
                    Explore our core service offerings designed to keep your
                    business running smoothly.
                </p>
            </div>

            <div class="services-grid">

                <div class="service-card">
                    <h3>Managed IT Support</h3>
                    <p>
                        Ongoing monitoring, maintenance, troubleshooting,
                        software updates, and technology support.
                    </p>
                </div>

                <div class="service-card">
                    <h3>Cybersecurity</h3>
                    <p>
                        Antivirus management, threat detection, password
                        protection, employee security guidance, and monitoring.
                    </p>
                </div>

                <div class="service-card">
                    <h3>Computer Repair</h3>
                    <p>
                        Hardware diagnostics, software repairs, upgrades,
                        troubleshooting, and system optimization.
                    </p>
                </div>

                <div class="service-card">
                    <h3>Cloud Solutions</h3>
                    <p>
                        Microsoft 365 setup, cloud storage, cloud backups,
                        file sharing, and remote collaboration solutions.
                    </p>
                </div>

                <div class="service-card">
                    <h3>Network Setup</h3>
                    <p>
                        Wi-Fi deployment, office networking, firewall setup,
                        printer connections, and network maintenance.
                    </p>
                </div>

                <div class="service-card">
                    <h3>Help Desk Support</h3>
                    <p>
                        Fast remote assistance for employees experiencing
                        technology issues or technical questions.
                    </p>
                </div>

            </div>

        </div>
    </section>

    <!-- PROCESS -->
    <section class="section alt-section">
        <div class="container">

            <div class="section-heading">
                <span class="eyebrow">How It Works</span>
                <h2>Simple Support Process</h2>
            </div>

            <div class="stats-grid">

                <div class="stat-card">
                    <strong>1</strong>
                    <span>Contact Our Team</span>
                </div>

                <div class="stat-card">
                    <strong>2</strong>
                    <span>Assess Your Needs</span>
                </div>

                <div class="stat-card">
                    <strong>3</strong>
                    <span>Create A Solution</span>
                </div>

                <div class="stat-card">
                    <strong>4</strong>
                    <span>Ongoing Support</span>
                </div>

            </div>

        </div>
    </section>

    <!-- FEATURED SERVICE -->
    <section class="section">
        <div class="container">

            <div class="split-layout">

                <div>
                    <span class="eyebrow">Business Technology</span>

                    <h2>Managed IT Services</h2>

                    <p>
                        Let us handle system updates, monitoring, backups,
                        security checks, and user support so your team can
                        focus on running the business.
                    </p>

                    <ul>
                        <li>24/7 Monitoring</li>
                        <li>Remote Support</li>
                        <li>Patch Management</li>
                        <li>Backup Solutions</li>
                    </ul>
                </div>

                <div class="info-box">

                    <h3>Included Benefits</h3>

                    <ul>
                        <li>Reduced Downtime</li>
                        <li>Improved Security</li>
                        <li>Predictable IT Costs</li>
                        <li>Professional Support</li>
                        <li>Scalable Solutions</li>
                    </ul>

                </div>

            </div>

        </div>
    </section>

    <!-- CTA -->
    <section class="section">
        <div class="container">

            <div class="cta-box">

                <h2>Need Help With Your Technology?</h2>

                <p>
                    Contact our team today and discover how TechPulse IT can
                    support your business.
                </p>

                <a href="<?php echo esc_url( home_url('/contact/') ); ?>" class="btn-primary">
                    Request Support
                </a>

            </div>

        </div>
    </section>

</main>

<?php get_footer(); ?>
