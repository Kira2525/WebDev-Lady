<?php
/**
 * 404 Error Page
 */

get_header();
?>

<main>

    <section class="page-hero">
        <div class="container">

            <span class="eyebrow">404 Error</span>

            <h1>Page Not Found</h1>

            <p>
                The page you are looking for may have been moved, deleted,
                or never existed.
            </p>

        </div>
    </section>

    <section class="section">
        <div class="container">

            <div class="cta-box">

                <h2>Let’s Get You Back On Track</h2>

                <p>
                    You can return to the homepage, view our services,
                    or contact us for support.
                </p>

                <div class="button-row">

                    <a href="<?php echo esc_url(home_url('/')); ?>" class="btn-primary">
                        Back To Home
                    </a>

                    <a href="<?php echo esc_url(home_url('/services/')); ?>" class="btn-primary">
                        View Services
                    </a>

                    <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn-primary">
                        Contact Us
                    </a>

                </div>

            </div>

        </div>
    </section>

</main>

<?php get_footer(); ?>