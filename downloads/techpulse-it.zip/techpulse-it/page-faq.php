<?php
/**
 * Template Name: FAQ Page
 */

get_header();
?>

<main>

    <!-- HERO -->
    <section class="page-hero">
        <div class="container">
            <span class="eyebrow">Frequently Asked Questions</span>

            <h1>Answers To Common IT Support Questions</h1>

            <p>
                Find quick answers to common questions about our services,
                support plans, cybersecurity, and business technology solutions.
            </p>
        </div>
    </section>

    <!-- FAQ SECTION -->
    <section class="section">
        <div class="container">

            <div class="section-heading">
                <span class="eyebrow">FAQ</span>

                <h2>How Can We Help?</h2>

                <p>
                    Here are some of the most common questions businesses ask
                    before choosing an IT provider.
                </p>
            </div>

            <div class="faq-list">

                <div class="faq-item">
                    <h3>What services do you provide?</h3>
                    <p>
                        We provide managed IT support, cybersecurity services,
                        computer repair, cloud solutions, network setup, and
                        remote help desk support.
                    </p>
                </div>

                <div class="faq-item">
                    <h3>Do you offer remote support?</h3>
                    <p>
                        Yes. Many issues can be resolved remotely, allowing us
                        to provide fast support without requiring an onsite visit.
                    </p>
                </div>

                <div class="faq-item">
                    <h3>Can you help protect our business from cyber threats?</h3>
                    <p>
                        Yes. We help businesses improve security through
                        monitoring, antivirus management, backups, password
                        protection, and cybersecurity best practices.
                    </p>
                </div>

                <div class="faq-item">
                    <h3>Do you support small businesses?</h3>
                    <p>
                        Absolutely. Our services are designed to help small and
                        medium-sized businesses manage technology efficiently.
                    </p>
                </div>

                <div class="faq-item">
                    <h3>What happens if our systems go down?</h3>
                    <p>
                        Our team works quickly to diagnose the issue, restore
                        service, and minimize downtime for your business.
                    </p>
                </div>

                <div class="faq-item">
                    <h3>Can you help with cloud services?</h3>
                    <p>
                        Yes. We assist with cloud storage, Microsoft 365,
                        backups, collaboration tools, and cloud migrations.
                    </p>
                </div>

                <div class="faq-item">
                    <h3>Do you offer ongoing support plans?</h3>
                    <p>
                        Yes. We offer flexible monthly support plans designed
                        for businesses of different sizes and needs.
                    </p>
                </div>

                <div class="faq-item">
                    <h3>How quickly can support requests be handled?</h3>
                    <p>
                        Response times vary by service plan, but priority
                        support options are available for businesses that need
                        faster assistance.
                    </p>
                </div>

            </div>

        </div>
    </section>

    <!-- SUPPORT FEATURES -->
    <section class="section alt-section">
        <div class="container">

            <div class="section-heading">
                <span class="eyebrow">Why Businesses Choose Us</span>

                <h2>Reliable Technology Support</h2>
            </div>

            <div class="services-grid">

                <div class="service-card">
                    <h3>Fast Response</h3>
                    <p>
                        Quick assistance when technology issues affect your team.
                    </p>
                </div>

                <div class="service-card">
                    <h3>Security Focused</h3>
                    <p>
                        Modern security practices designed to protect business data.
                    </p>
                </div>

                <div class="service-card">
                    <h3>Business First</h3>
                    <p>
                        Technology solutions aligned with your business goals.
                    </p>
                </div>

            </div>

        </div>
    </section>

    <!-- SUPPORT GUARANTEE -->
    <section class="section">
        <div class="container">

            <div class="section-heading">
                <span class="eyebrow">Our Promise</span>

                <h2>Support You Can Count On</h2>

                <p>
                    We focus on fast response times, proactive maintenance,
                    and practical technology solutions that help businesses
                    stay productive.
                </p>
            </div>

            <div class="stats-grid">

                <div class="stat-card">
                    <strong>24/7</strong>
                    <span>Monitoring Available</span>
                </div>

                <div class="stat-card">
                    <strong>Fast</strong>
                    <span>Response Times</span>
                </div>

                <div class="stat-card">
                    <strong>Secure</strong>
                    <span>Technology Solutions</span>
                </div>

                <div class="stat-card">
                    <strong>Reliable</strong>
                    <span>Business Support</span>
                </div>

            </div>

        </div>
    </section>

    <!-- CTA -->
    <section class="section">
        <div class="container">

            <div class="cta-box">

                <h2>Still Have Questions?</h2>

                <p>
                    Contact our team and we'll be happy to discuss your
                    technology needs and recommend the right solution.
                </p>

                <a href="<?php echo esc_url( home_url('/contact/') ); ?>" class="btn-primary">
                    Contact Us
                </a>

            </div>

        </div>
    </section>

</main>

<?php get_footer(); ?>