<?php
/**
 * Theme Footer
 */
?>

<footer class="site-footer">

    <div class="footer-container">

        <div class="footer-brand">

            <h3><?php bloginfo('name'); ?></h3>

            <p>
                Professional IT support, cybersecurity, cloud solutions,
                and business technology services.
            </p>

        </div>

        <div class="footer-links">

            <h4>Quick Links</h4>

            <ul>
                <li>
                    <a href="<?php echo esc_url(home_url('/')); ?>">
                        Home
                    </a>
                </li>

                <li>
                    <a href="<?php echo esc_url(home_url('/about/')); ?>">
                        About
                    </a>
                </li>

                <li>
                    <a href="<?php echo esc_url(home_url('/services/')); ?>">
                        Services
                    </a>
                </li>

                <li>
                    <a href="<?php echo esc_url(home_url('/pricing/')); ?>">
                        Pricing
                    </a>
                </li>

                <li>
                    <a href="<?php echo esc_url(home_url('/contact/')); ?>">
                        Contact
                    </a>
                </li>
            </ul>

        </div>

        <div class="footer-contact">

            <h4>Contact</h4>

            <p>Email: support@example.com</p>

            <p>Phone: (555) 123-4567</p>

            <p>Phoenix, Arizona</p>

        </div>

    </div>

    <div class="footer-bottom">

        <p>
            &copy; <?php echo date('Y'); ?>
            <?php bloginfo('name'); ?>.
            All rights reserved.
        </p>

    </div>

</footer>

<?php wp_footer(); ?>

</body>
</html>