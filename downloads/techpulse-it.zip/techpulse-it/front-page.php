<?php get_header(); ?>

<main>

    <section class="hero">
        <div class="hero-grid">
            <div>
                <span class="badge">Fast, secure, reliable IT support</span>

                <h1>Modern IT Support for Growing Businesses</h1>

                <p>
                    TechPulse IT helps small businesses stay secure, connected,
                    and productive with expert tech support, managed IT services,
                    cybersecurity protection, and computer repair.
                </p>

                <div class="button-row">
                    <a class="button" href="<?php echo esc_url(home_url('/contact/')); ?>">
                        Request Support
                    </a>

                    <a class="button secondary" href="<?php echo esc_url(home_url('/services/')); ?>">
                        View Services
                    </a>
                </div>
            </div>

            <div class="hero-panel">
                <div class="status-line">
                    <span>Network Monitoring</span>
                    <strong>Online</strong>
                </div>

                <div class="status-line">
                    <span>Device Protection</span>
                    <strong>Active</strong>
                </div>

                <div class="status-line">
                    <span>Cloud Backup</span>
                    <strong>Secured</strong>
                </div>

                <div class="status-line">
                    <span>Help Desk</span>
                    <strong>Ready</strong>
                </div>
            </div>
        </div>
    </section>

    <section class="section" id="services">
        <div class="section-header">
            <span class="eyebrow">Our Services</span>

            <h2>IT Services Built for Real Business Problems</h2>

            <p>
                From broken computers to full business tech support, this theme
                is made for IT companies that want to look professional fast.
            </p>
        </div>

        <div class="cards">
            <div class="card">
                <h3>Managed IT Support</h3>
                <p>
                    Ongoing tech support, system monitoring, device setup,
                    troubleshooting, and business technology help.
                </p>
            </div>

            <div class="card">
                <h3>Cybersecurity</h3>
                <p>
                    Protect business data with security checks, antivirus setup,
                    password guidance, and safer systems.
                </p>
            </div>

            <div class="card">
                <h3>Computer Repair</h3>
                <p>
                    Hardware fixes, software cleanup, slow computer repair,
                    operating system issues, and diagnostics.
                </p>
            </div>

            <div class="card">
                <h3>Cloud Solutions</h3>
                <p>
                    Email setup, file storage, cloud backups, Microsoft 365,
                    Google Workspace, and remote access support.
                </p>
            </div>

            <div class="card">
                <h3>Network Setup</h3>
                <p>
                    Wi-Fi setup, router configuration, office networking,
                    printer connections, and secure access.
                </p>
            </div>

            <div class="card">
                <h3>Help Desk Support</h3>
                <p>
                    Remote and onsite support for teams that need fast answers
                    when technology stops working.
                </p>
            </div>
        </div>
    </section>

    <section class="section" id="pricing">
        <div class="section-header">
            <span class="eyebrow">Pricing</span>

            <h2>Simple IT Support Plans</h2>

            <p>
                Use this section for monthly IT plans, repair packages,
                or custom service pricing.
            </p>
        </div>

        <div class="cards">
            <div class="card">
                <h3>Starter</h3>

                <div class="price">$99<span>/mo</span></div>

                <ul class="list">
                    <li>Basic remote support</li>
                    <li>Email support</li>
                    <li>Device setup help</li>
                    <li>Monthly system check</li>
                </ul>

                <a class="button" href="<?php echo esc_url(home_url('/contact/')); ?>">
                    Choose Plan
                </a>
            </div>

            <div class="card featured-card">
                <span class="popular-badge">Most Popular</span>

                <h3>Business</h3>

                <div class="price">$249<span>/mo</span></div>

                <ul class="list">
                    <li>Priority support</li>
                    <li>Security monitoring</li>
                    <li>Cloud backup guidance</li>
                    <li>Network troubleshooting</li>
                </ul>

                <a class="button" href="<?php echo esc_url(home_url('/contact/')); ?>">
                    Choose Plan
                </a>
            </div>

            <div class="card">
                <h3>Pro</h3>

                <div class="price">$499<span>/mo</span></div>

                <ul class="list">
                    <li>Managed IT support</li>
                    <li>Cybersecurity checks</li>
                    <li>Remote and onsite help</li>
                    <li>Business technology planning</li>
                </ul>

                <a class="button" href="<?php echo esc_url(home_url('/contact/')); ?>">
                    Choose Plan
                </a>
            </div>
        </div>
    </section>

    <section class="section" id="faq">
        <div class="section-header">
            <span class="eyebrow">FAQ</span>

            <h2>Frequently Asked Questions</h2>
        </div>

        <div class="cards">
            <div class="card">
                <h3>Do you offer remote support?</h3>
                <p>
                    Yes. Most software, email, security, and troubleshooting
                    issues can be handled remotely.
                </p>
            </div>

            <div class="card">
                <h3>Can this be used for computer repair?</h3>
                <p>
                    Yes. The theme works for computer repair shops, IT consultants,
                    MSPs, and tech support businesses.
                </p>
            </div>

            <div class="card">
                <h3>Can the prices be changed?</h3>
                <p>
                    Yes. The buyer can edit the pricing text directly inside the
                    theme files or WordPress pages.
                </p>
            </div>
        </div>
    </section>

    <section class="section" id="contact">
        <div class="cta-box">
            <h2>Need IT Help Today?</h2>

            <p>
                Replace this button with a contact form, booking link, phone
                number, or quote request page.
            </p>

            <a class="button" href="<?php echo esc_url(home_url('/contact/')); ?>">
                Request a Quote
            </a>
        </div>
    </section>

</main>

<?php get_footer(); ?>